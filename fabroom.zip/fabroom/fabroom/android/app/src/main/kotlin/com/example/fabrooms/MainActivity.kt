package com.example.fabrooms

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
